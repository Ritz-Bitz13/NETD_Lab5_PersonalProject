﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FirstMVCApp.Models
{
    public class FirstModel
    {

        public string message = "Hello from the First Model this was edited without a lot of work.";
    }
}
